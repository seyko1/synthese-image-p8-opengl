/*!\file animations.h
 *
 * \brief Votre espace de liberté : c'est ici que vous pouvez ajouter
 * vos fonctions de transition et d'animation avant de les faire
 * référencées dans le tableau _animations du fichier \ref window.c
 *
 * Des squelettes d'animations et de transitions sont fournis pour
 * comprendre le fonctionnement de la bibliothèque. En bonus des
 * exemples dont un fondu en GLSL.
 *
 * \author Farès BELHADJ, amsi@up8.edu
 * \date April 12, 2023
 */
#ifndef _ANIMATIONS_H

#define _ANIMATIONS_H

#ifdef __cplusplus
extern "C" {
#endif

  extern void fondu(void (* a0)(int), void (* a1)(int), Uint32 t, Uint32 et, int state);
  extern void animationsInit(void);
  
  // from ondulations.c
  extern void ondulations(int state);
  
  // from mandelbulbFractal.c
  extern void mandelbulbFractal(int state);
  
  // from gameoflife3D.c
  extern void gameoflife3D(int state);

  // from flyingTrip.c
  extern void flyingTrip(int state);

  // from sphericalInversion.c
  extern void sphericalInversion(int state);
  
  // from credit.c
  extern void credit(int state);

#ifdef __cplusplus
}
#endif

#endif
