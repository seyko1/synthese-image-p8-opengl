#version 330

layout(location = 0) in vec3 pos;
layout(location = 1) in vec3 normal;
layout(location = 2) in vec2 texCoord;

uniform mat4 model, view, projection;

out vec3 vPos;

void main() {
    gl_Position = projection * view * model * vec4(pos, 1.0);
    vPos = pos;
}